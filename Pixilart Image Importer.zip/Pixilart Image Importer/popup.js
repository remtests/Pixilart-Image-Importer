/* ============================================================
   Pixilart Image Importer — popup.js
   Pipeline : charger image -> redimensionner -> quantifier
   (median cut) -> dithering (none / Floyd-Steinberg / Bayer /
   halftone) -> preview temps réel -> export PNG / .pixil /
   injection dans Pixilart via son presse-papier interne.
   ============================================================ */

const el = (id) => document.getElementById(id);

const dropzone = el('dropzone');
const dropLabel = el('dropLabel');
const fileInput = el('fileInput');
const originalCanvas = el('originalCanvas');
const processedCanvasEl = el('processedCanvas');
const origDimsEl = el('origDims');
const procDimsEl = el('procDims');

const colorsRange = el('colorsRange');
const colorsNumber = el('colorsNumber');
const algoSelect = el('algoSelect');
const scaleRange = el('scaleRange');
const scaleNumber = el('scaleNumber');
const lockRatio = el('lockRatio');
const widthInput = el('widthInput');
const heightInput = el('heightInput');
const removeBg = el('removeBg');
const bgTolerance = el('bgTolerance');
const bgToleranceNumber = el('bgToleranceNumber');

const statusEl = el('status');
const btnPixil = el('btnPixil');
const btnInject = el('btnInject');
const btnPng = el('btnPng');

const state = {
  img: null,
  origW: 0,
  origH: 0,
  targetW: 0,
  targetH: 0,
  processedCanvas: document.createElement('canvas'), // buffer plein format (pas d'échelle CSS)
};

let processTimer = null;

/* ---------------- Chargement de l'image ---------------- */

dropzone.addEventListener('click', () => fileInput.click());
fileInput.addEventListener('change', (e) => {
  if (e.target.files && e.target.files[0]) loadFile(e.target.files[0]);
});
['dragover', 'dragenter'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.add('drag-over');
  })
);
['dragleave', 'drop'].forEach((evt) =>
  dropzone.addEventListener(evt, (e) => {
    e.preventDefault();
    dropzone.classList.remove('drag-over');
  })
);
dropzone.addEventListener('drop', (e) => {
  const f = e.dataTransfer.files && e.dataTransfer.files[0];
  if (f) loadFile(f);
});

function loadFile(file) {
  if (!file.type.startsWith('image/')) {
    setStatus("Le fichier sélectionné n'est pas une image.", 'error');
    return;
  }
  const reader = new FileReader();
  reader.onload = () => {
    const img = new Image();
    img.onload = () => {
      state.img = img;
      state.origW = img.naturalWidth;
      state.origH = img.naturalHeight;
      state.targetW = img.naturalWidth;
      state.targetH = img.naturalHeight;

      originalCanvas.width = state.origW;
      originalCanvas.height = state.origH;
      originalCanvas.getContext('2d').drawImage(img, 0, 0);
      origDimsEl.textContent = `${state.origW} × ${state.origH}px`;

      scaleRange.value = 100;
      scaleNumber.value = 100;
      widthInput.value = state.origW;
      heightInput.value = state.origH;

      dropLabel.textContent = file.name;

      btnPixil.disabled = false;
      btnInject.disabled = false;
      btnPng.disabled = false;

      scheduleProcess(true);
    };
    img.onerror = () => setStatus("Impossible de charger cette image.", 'error');
    img.src = reader.result;
  };
  reader.readAsDataURL(file);
}

/* ---------------- Contrôles UI ---------------- */

colorsRange.addEventListener('input', () => {
  colorsNumber.value = colorsRange.value;
  scheduleProcess();
});
colorsNumber.addEventListener('input', () => {
  let v = clamp(parseInt(colorsNumber.value || '2', 10), 2, 256);
  colorsNumber.value = v;
  colorsRange.value = v;
  scheduleProcess();
});

algoSelect.addEventListener('change', () => scheduleProcess());

scaleRange.addEventListener('input', () => {
  scaleNumber.value = scaleRange.value;
  applyScalePercent(parseInt(scaleRange.value, 10));
  scheduleProcess();
});
scaleNumber.addEventListener('input', () => {
  let v = clamp(parseInt(scaleNumber.value || '1', 10), 1, 100);
  scaleNumber.value = v;
  scaleRange.value = v;
  applyScalePercent(v);
  scheduleProcess();
});

widthInput.addEventListener('input', () => {
  if (!state.origW) return;
  let w = clamp(parseInt(widthInput.value || '1', 10), 1, 4096);
  state.targetW = w;
  if (lockRatio.checked) {
    state.targetH = Math.max(1, Math.round(w * state.origH / state.origW));
    heightInput.value = state.targetH;
  } else {
    state.targetH = parseInt(heightInput.value || state.targetH, 10);
  }
  syncScaleFromWidth();
  scheduleProcess();
});
heightInput.addEventListener('input', () => {
  if (!state.origH) return;
  let h = clamp(parseInt(heightInput.value || '1', 10), 1, 4096);
  state.targetH = h;
  if (lockRatio.checked) {
    state.targetW = Math.max(1, Math.round(h * state.origW / state.origH));
    widthInput.value = state.targetW;
  } else {
    state.targetW = parseInt(widthInput.value || state.targetW, 10);
  }
  syncScaleFromWidth();
  scheduleProcess();
});
lockRatio.addEventListener('change', () => {
  if (lockRatio.checked && state.origW) {
    // Recale la hauteur sur la largeur actuelle pour retrouver le ratio d'origine
    state.targetH = Math.max(1, Math.round(state.targetW * state.origH / state.origW));
    heightInput.value = state.targetH;
    scheduleProcess();
  }
});

function applyScalePercent(pct) {
  if (!state.origW) return;
  state.targetW = Math.max(1, Math.round(state.origW * pct / 100));
  state.targetH = Math.max(1, Math.round(state.origH * pct / 100));
  widthInput.value = state.targetW;
  heightInput.value = state.targetH;
}
function syncScaleFromWidth() {
  if (!state.origW) return;
  const pct = clamp(Math.round((state.targetW / state.origW) * 100), 1, 999);
  scaleNumber.value = pct;
  if (pct <= 100) scaleRange.value = pct;
}
function clamp(v, min, max) {
  if (isNaN(v)) return min;
  return Math.min(max, Math.max(min, v));
}

removeBg.addEventListener('change', () => {
  bgTolerance.disabled = !removeBg.checked;
  bgToleranceNumber.disabled = !removeBg.checked;
  scheduleProcess();
});
bgTolerance.addEventListener('input', () => {
  bgToleranceNumber.value = bgTolerance.value;
  scheduleProcess();
});
bgToleranceNumber.addEventListener('input', () => {
  let v = clamp(parseInt(bgToleranceNumber.value || '0', 10), 0, 100);
  bgToleranceNumber.value = v;
  bgTolerance.value = v;
  scheduleProcess();
});

/* ---------------- Pipeline de traitement (temps réel) ---------------- */

function scheduleProcess(immediate) {
  if (!state.img) return;
  clearTimeout(processTimer);
  processTimer = setTimeout(processImage, immediate ? 0 : 40);
}

function processImage() {
  const w = state.targetW, h = state.targetH;
  if (!w || !h) return;

  // 1) Redimensionnement (avec lissage, pour une réduction représentative)
  const resized = document.createElement('canvas');
  resized.width = w;
  resized.height = h;
  const rctx = resized.getContext('2d');
  rctx.imageSmoothingEnabled = true;
  rctx.imageSmoothingQuality = 'high';
  rctx.drawImage(state.img, 0, 0, w, h);

  let imageData = rctx.getImageData(0, 0, w, h);

  // 2) Suppression de fond (optionnelle) — flood-fill léger depuis les bords
  if (removeBg.checked) {
    const tol = clamp(parseInt(bgToleranceNumber.value, 10) || 0, 0, 100);
    removeBackground(imageData, w, h, tol);
  }

  // 3) Palette (median cut) à partir des pixels opaques
  const maxColors = clamp(parseInt(colorsNumber.value, 10) || 16, 2, 256);
  const palette = buildPalette(imageData.data, maxColors);

  // 3) Dithering / mapping vers la palette
  const algo = algoSelect.value;
  applyAlgorithm(imageData, w, h, palette, algo);

  // 4) Rendu dans le canvas de traitement (buffer) + preview
  state.processedCanvas.width = w;
  state.processedCanvas.height = h;
  state.processedCanvas.getContext('2d').putImageData(imageData, 0, 0);

  processedCanvasEl.width = w;
  processedCanvasEl.height = h;
  processedCanvasEl.getContext('2d').putImageData(imageData, 0, 0);

  procDimsEl.textContent = `${w} × ${h}px — ${palette.length} couleurs`;
}

/* ---------------- Suppression de fond (flood-fill léger) ---------------- */
/* Hypothèse simple : le fond est une zone de couleur ~uniforme connectée aux
   bords de l'image (couleur moyenne des 4 coins comme référence). On part
   des pixels de bordure et on propage (4-connexité) vers les pixels voisins
   dont la couleur reste dans la tolérance, en les rendant transparents.
   Léger : O(largeur × hauteur), une seule passe, sans dépendance externe. */

function removeBackground(imageData, w, h, tolerancePct) {
  const data = imageData.data;
  const visited = new Uint8Array(w * h);
  const maxDist = 441.7; // sqrt(255^2 * 3), distance euclidienne RGB max
  const tolSq = Math.pow((tolerancePct / 100) * maxDist, 2);

  // Couleur de référence : moyenne des coins non déjà transparents
  const corners = [[0, 0], [w - 1, 0], [0, h - 1], [w - 1, h - 1]];
  let rSum = 0, gSum = 0, bSum = 0, count = 0;
  for (const [cx, cy] of corners) {
    const i = (cy * w + cx) * 4;
    if (data[i + 3] > 10) { rSum += data[i]; gSum += data[i + 1]; bSum += data[i + 2]; count++; }
  }
  if (count === 0) return;
  const ref = [rSum / count, gSum / count, bSum / count];

  const stack = [];
  function tryFill(x, y) {
    if (x < 0 || x >= w || y < 0 || y >= h) return;
    const idx = y * w + x;
    if (visited[idx]) return;
    visited[idx] = 1;
    const i = idx * 4;
    if (data[i + 3] <= 10) return; // déjà transparent
    const dr = data[i] - ref[0], dg = data[i + 1] - ref[1], db = data[i + 2] - ref[2];
    if (dr * dr + dg * dg + db * db <= tolSq) {
      data[i + 3] = 0;
      stack.push(x, y);
    }
  }

  for (let x = 0; x < w; x++) { tryFill(x, 0); tryFill(x, h - 1); }
  for (let y = 0; y < h; y++) { tryFill(0, y); tryFill(w - 1, y); }

  while (stack.length) {
    const y = stack.pop(), x = stack.pop();
    tryFill(x + 1, y); tryFill(x - 1, y); tryFill(x, y + 1); tryFill(x, y - 1);
  }
}

/* ---------------- Median cut : construction de palette ---------------- */

function buildPalette(data, maxColors) {
  const pixels = [];
  for (let i = 0; i < data.length; i += 4) {
    if (data[i + 3] > 10) pixels.push([data[i], data[i + 1], data[i + 2]]);
  }
  if (pixels.length === 0) return [[0, 0, 0]];

  let buckets = [pixels];
  while (buckets.length < maxColors) {
    let idx = -1, maxRange = -1, channel = 0;
    for (let bi = 0; bi < buckets.length; bi++) {
      const b = buckets[bi];
      if (b.length < 2) continue;
      for (let c = 0; c < 3; c++) {
        let min = 255, max = 0;
        for (let p = 0; p < b.length; p++) {
          const v = b[p][c];
          if (v < min) min = v;
          if (v > max) max = v;
        }
        const range = max - min;
        if (range > maxRange) { maxRange = range; idx = bi; channel = c; }
      }
    }
    if (idx === -1 || maxRange <= 0) break;
    const bucket = buckets[idx];
    bucket.sort((a, b) => a[channel] - b[channel]);
    const mid = Math.floor(bucket.length / 2);
    buckets.splice(idx, 1, bucket.slice(0, mid), bucket.slice(mid));
  }

  return buckets.filter((b) => b.length).map((b) => {
    let r = 0, g = 0, bl = 0;
    for (const p of b) { r += p[0]; g += p[1]; bl += p[2]; }
    const n = b.length;
    return [Math.round(r / n), Math.round(g / n), Math.round(bl / n)];
  });
}

function nearestColor(r, g, b, palette) {
  let best = 0, bestDist = Infinity;
  for (let i = 0; i < palette.length; i++) {
    const p = palette[i];
    const dr = r - p[0], dg = g - p[1], db = b - p[2];
    const d = dr * dr + dg * dg + db * db;
    if (d < bestDist) { bestDist = d; best = i; }
  }
  return palette[best];
}

/* ---------------- Matrices de tramage ---------------- */

// Bayer 8x8 dispersé (tramage ordonné classique)
const BAYER8 = [
  0, 32, 8, 40, 2, 34, 10, 42,
  48, 16, 56, 24, 50, 18, 58, 26,
  12, 44, 4, 36, 14, 46, 6, 38,
  60, 28, 52, 20, 62, 30, 54, 22,
  3, 35, 11, 43, 1, 33, 9, 41,
  51, 19, 59, 27, 49, 17, 57, 25,
  15, 47, 7, 39, 13, 45, 5, 37,
  63, 31, 55, 23, 61, 29, 53, 21,
];

// Matrice "point groupé" 8x8 (effet halftone / motif de points)
const CLUSTER8 = [
  24, 10, 12, 26, 35, 47, 49, 37,
  8, 0, 2, 14, 45, 59, 57, 51,
  22, 6, 4, 16, 43, 61, 63, 53,
  30, 20, 18, 28, 33, 41, 39, 55,
  34, 46, 48, 36, 25, 11, 13, 27,
  44, 58, 56, 50, 9, 1, 3, 15,
  42, 60, 62, 52, 23, 7, 5, 17,
  32, 40, 38, 54, 31, 21, 19, 29,
];

function applyAlgorithm(imageData, w, h, palette, algo) {
  const data = imageData.data;

  if (algo === 'none') {
    for (let i = 0; i < data.length; i += 4) {
      if (data[i + 3] <= 10) continue;
      const c = nearestColor(data[i], data[i + 1], data[i + 2], palette);
      data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2];
    }
    return;
  }

  if (algo === 'bayer' || algo === 'halftone') {
    const matrix = algo === 'bayer' ? BAYER8 : CLUSTER8;
    const amplitude = 48; // intensité du biais de tramage
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const i = (y * w + x) * 4;
        if (data[i + 3] <= 10) continue;
        const m = matrix[(y % 8) * 8 + (x % 8)] / 63 - 0.5; // [-0.5, 0.5]
        const bias = m * amplitude;
        const r = clamp(data[i] + bias, 0, 255);
        const g = clamp(data[i + 1] + bias, 0, 255);
        const b = clamp(data[i + 2] + bias, 0, 255);
        const c = nearestColor(r, g, b, palette);
        data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2];
      }
    }
    return;
  }

  if (algo === 'floyd') {
    // Buffers flottants pour la diffusion d'erreur
    const rBuf = new Float32Array(w * h);
    const gBuf = new Float32Array(w * h);
    const bBuf = new Float32Array(w * h);
    const aBuf = new Uint8Array(w * h);
    for (let p = 0, i = 0; p < w * h; p++, i += 4) {
      rBuf[p] = data[i]; gBuf[p] = data[i + 1]; bBuf[p] = data[i + 2]; aBuf[p] = data[i + 3];
    }
    for (let y = 0; y < h; y++) {
      for (let x = 0; x < w; x++) {
        const p = y * w + x;
        if (aBuf[p] <= 10) continue;
        const oldR = clamp(rBuf[p], 0, 255);
        const oldG = clamp(gBuf[p], 0, 255);
        const oldB = clamp(bBuf[p], 0, 255);
        const c = nearestColor(oldR, oldG, oldB, palette);
        const i = p * 4;
        data[i] = c[0]; data[i + 1] = c[1]; data[i + 2] = c[2];

        const errR = oldR - c[0], errG = oldG - c[1], errB = oldB - c[2];
        diffuse(x + 1, y, 7 / 16);
        diffuse(x - 1, y + 1, 3 / 16);
        diffuse(x, y + 1, 5 / 16);
        diffuse(x + 1, y + 1, 1 / 16);

        function diffuse(nx, ny, factor) {
          if (nx < 0 || nx >= w || ny < 0 || ny >= h) return;
          const np = ny * w + nx;
          if (aBuf[np] <= 10) return;
          rBuf[np] += errR * factor;
          gBuf[np] += errG * factor;
          bBuf[np] += errB * factor;
        }
      }
    }
  }
}

/* ---------------- Export PNG ---------------- */

btnPng.addEventListener('click', () => {
  if (!state.processedCanvas.width) return;
  state.processedCanvas.toBlob((blob) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pixel-art.png';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    setStatus('PNG téléchargé.', 'ok');
  }, 'image/png');
});

/* ---------------- Export .pixil ---------------- */
/* Format .pixil non documenté officiellement : reconstruction
   "best effort" (archive zip + data.json + calque PNG). Si
   Pixilart n'accepte pas ce fichier tel quel, préférez l'export
   PNG ou l'injection directe. */

btnPixil.addEventListener('click', async () => {
  if (!state.processedCanvas.width) return;
  setStatus('Génération du fichier .pixil...', '');
  try {
    const w = state.processedCanvas.width, h = state.processedCanvas.height;
    const pngBlob = await new Promise((res) => state.processedCanvas.toBlob(res, 'image/png'));

    const zip = new JSZip();
    const dataJson = {
      version: 1,
      width: w,
      height: h,
      frames: [
        {
          layers: [
            { name: 'Layer 1', opacity: 1, visible: true, image: 'layer0.png' },
          ],
        },
      ],
    };
    zip.file('data.json', JSON.stringify(dataJson, null, 2));
    zip.file('layer0.png', pngBlob);

    const blob = await zip.generateAsync({ type: 'blob' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pixel-art.pixil';
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 4000);
    setStatus('.pixil téléchargé (format reconstruit, non officiel).', 'ok');
  } catch (e) {
    setStatus("Erreur lors de la génération du .pixil : " + e.message, 'error');
  }
});

/* ---------------- Injection dans Pixilart ---------------- */

btnInject.addEventListener('click', async () => {
  if (!state.processedCanvas.width) return;
  setStatus('Connexion à Pixilart...', '');
  btnInject.disabled = true;
  try {
    const dataUrl = state.processedCanvas.toDataURL('image/png');
    const w = state.processedCanvas.width, h = state.processedCanvas.height;
    const response = await chrome.runtime.sendMessage({
      type: 'inject-image',
      dataUrl, width: w, height: h,
    });
    if (response && response.ok) {
      setStatus('Image injectée dans Pixilart !', 'ok');
    } else {
      setStatus('Échec : ' + (response && response.error ? response.error : 'raison inconnue'), 'error');
    }
  } catch (e) {
    setStatus('Erreur : ' + e.message, 'error');
  } finally {
    btnInject.disabled = false;
  }
});

function setStatus(msg, kind) {
  statusEl.textContent = msg;
  statusEl.className = 'status' + (kind ? ' ' + kind : '');
}
