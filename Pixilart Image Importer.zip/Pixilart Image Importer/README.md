# Pixilart Image Importer

Extension Chrome (non publiée / usage local) qui convertit une image en pixel
art puis l'injecte directement dans l'éditeur de https://www.pixilart.com,
via son système interne de copier/coller (`SelectController`).

## Installation (mode développeur)

1. Dézippez ce dossier.
2. Ouvrez `chrome://extensions`.
3. Activez le mode développeur (en haut à droite).
4. Cliquez sur « Charger l'extension non empaquetée » et sélectionnez le
   dossier `pixilart-extension`.
5. Ouvrez un projet dans l'éditeur Pixilart.com.
6. Cliquez sur l'icône de l'extension.

## Fonctionnement du popup

- **Zone de dépôt** : cliquez ou glissez-déposez une image.
- **Deux previews côte à côte** : image d'origine à gauche, résultat du
  post-traitement à droite, mis à jour en temps réel à chaque changement de
  réglage.
- **Couleurs max** : nombre de couleurs de la palette générée par
  quantification *median cut*.
- **Algorithme** :
  - *Aucun* : chaque pixel prend la couleur de palette la plus proche.
  - *Floyd–Steinberg* : diffusion d'erreur (meilleur rendu de dégradés).
  - *Tramage ordonné (Bayer)* : motif de trame dispersée classique.
  - *Motif de points (halftone)* : trame à points groupés façon halftone.
- **Résolution (%)** : redimensionne l'image (proportionnellement) avant
  quantification.
- **L / H (px)** + **Verrouiller le ratio** : ajustement fin en pixels ;
  décochez le verrou pour étirer librement l'image.

## Boutons

- **PNG** : télécharge le résultat post-traitement en PNG.
- **.pixil** : génère un fichier `.pixil` (archive ZIP contenant
  `data.json` + le calque en PNG). ⚠️ Le format `.pixil` de Pixilart n'est
  pas documenté publiquement : ceci est une reconstruction *best effort*.
  Si Pixilart refuse le fichier, utilisez le PNG ou l'injection directe.
- **Injecter dans Pixilart** : envoie l'image directement dans le
  presse-papier interne de l'éditeur (comme un Ctrl+V), en position centrée
  sur le canevas actif.

## Comment fonctionne l'injection (et pourquoi la permission `debugger`)

Pixilart ne lit pas le presse-papier du système : son raccourci Ctrl+V
appelle une méthode interne `pasteSelection()` sur un objet
`SelectController`, instancié en closure et jamais exposé sur `window`.
Impossible d'y accéder depuis un script de contenu classique.

L'extension utilise donc `chrome.debugger` (Chrome DevTools Protocol) pour :

1. Repérer dans le bundle `pixilart_app.js` le gestionnaire de touches où la
   variable `e` correspond à l'instance `SelectController`.
2. Poser un point d'arrêt **conditionnel** dont la condition est en réalité
   une expression à effet de bord : `(window.__pixilLeak = e, false)`. Elle
   s'évalue toujours à `false`, donc l'exécution ne s'interrompt jamais et
   n'a aucun impact visible ; mais l'instance est copiée dans
   `window.__pixilLeak` à chaque frappe clavier sur la page.
3. Déclencher un `keydown` neutre (sans touche réelle) pour forcer
   l'exécution du handler une fois, capturer l'instance, puis **détacher
   immédiatement** le débogueur (Chrome affiche un bandeau « ... a démarré
   le débogage de ce navigateur » pendant une fraction de seconde).
4. Une fois `window.__pixilLeak` disponible, un script exécuté dans le
   contexte principal de la page (`world: "MAIN"`) définit
   `instance.copyData = { image, width, height }` puis appelle
   `instance.pasteSelection()` — exactement ce que fait Pixilart lors d'un
   vrai Ctrl+V.

C'est nécessairement **fragile** : si Pixilart met à jour son bundle
(minification différente, code restructuré), le texte-ancre recherché
(`46==t.keyCode&&e.deleteSelection()`) peut ne plus exister, et l'injection
échouera avec un message d'erreur explicite dans le popup — dans ce cas,
repliez-vous sur les exports PNG / `.pixil`.

## Permissions demandées

- `activeTab`, `scripting` : exécuter du code dans l'onglet actif.
- `debugger` : capture de l'instance interne décrite ci-dessus.
- `downloads` : non utilisé directement (les téléchargements passent par un
  lien `<a download>`), laissé au cas où vous préfériez migrer vers
  `chrome.downloads` plus tard.
- `host_permissions` sur `https://www.pixilart.com/*` uniquement.
