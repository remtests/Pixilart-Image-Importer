/* ============================================================
   Pixilart Image Importer — background.js (service worker)
   ------------------------------------------------------------
   Pixilart gère son copier/coller en interne (pas le presse-
   papier du navigateur) via une classe "SelectController"
   (minifiée en "K" dans le bundle pixilart_app.js), instanciée
   en closure et non exposée sur `window`.

   Pour pouvoir appeler SelectController.pasteSelection() depuis
   l'extension, on récupère une référence vivante à l'instance
   grâce à un point d'arrêt conditionnel (CDP / chrome.debugger) :
   on repère dans le bundle le gestionnaire "keydown" de la classe
   (où la variable `e` capture `this`, l'instance), on y pose un
   point d'arrêt dont la "condition" est en réalité une expression
   avec effet de bord : `(window.__pixilLeak = e, false)`.
   Cette condition s'évalue à `false`, donc l'exécution ne
   s'interrompt JAMAIS (aucun impact visible), mais l'assignation
   a bien lieu à chaque frappe clavier sur la page.

   On déclenche ensuite nous-mêmes un événement clavier neutre
   (keyCode 0, sans effet dans l'app) pour forcer l'exécution du
   handler et capturer l'instance, puis on détache immédiatement
   le débogueur.

   ⚠️ Fragile par nature : si Pixilart change son bundle, le texte
   "ancre" recherché ci-dessous peut ne plus correspondre. Dans ce
   cas, utilisez les exports PNG / .pixil à la place.
   ============================================================ */

const SCRIPT_URL_HINT = 'pixilart_app.js';
// Ancre textuelle stable dans le handler keydown de SelectController
// (cf. le extrait fourni : "46==t.keyCode&&e.deleteSelection()").
const ANCHOR_TEXT = '46==t.keyCode&&e.deleteSelection()';
const LEAK_VAR = '__pixilLeak';

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'inject-image') {
    handleInject(msg.dataUrl, msg.width, msg.height)
      .then((res) => sendResponse(res))
      .catch((e) => sendResponse({ ok: false, error: String(e && e.message || e) }));
    return true; // réponse asynchrone
  }
});

async function handleInject(dataUrl, width, height) {
  const tabs = await chrome.tabs.query({ active: true, currentWindow: true });
  const tab = tabs[0];
  if (!tab || !tab.url || !tab.url.includes('pixilart.com')) {
    throw new Error("Ouvrez un onglet de l'éditeur Pixilart.com actif, puis réessayez.");
  }
  const tabId = tab.id;

  const already = await hasLeak(tabId);
  if (!already) {
    await captureInstance(tabId);
    const ok = await hasLeak(tabId);
    if (!ok) throw new Error("Impossible de récupérer l'éditeur Pixilart (structure de page inattendue).");
  }

  const [{ result }] = await chrome.scripting.executeScript({
    target: { tabId },
    world: 'MAIN',
    func: (leakVar, dataUrl, width, height) => {
      return new Promise((resolve) => {
        try {
          const inst = window[leakVar];
          if (!inst || typeof inst.pasteSelection !== 'function') {
            resolve({ ok: false, error: "Référence interne introuvable ou invalide." });
            return;
          }
          const img = new Image();
          img.onload = () => {
            try {
              inst.copyData = { image: img, width: width, height: height };
              inst.pasteSelection();
              resolve({ ok: true });
            } catch (e) {
              resolve({ ok: false, error: 'pasteSelection() a échoué : ' + e.message });
            }
          };
          img.onerror = () => resolve({ ok: false, error: "Échec de chargement de l'image générée." });
          img.src = dataUrl;
        } catch (e) {
          resolve({ ok: false, error: String(e && e.message || e) });
        }
      });
    },
    args: [LEAK_VAR, dataUrl, width, height],
  });

  return result;
}

async function hasLeak(tabId) {
  try {
    const [{ result }] = await chrome.scripting.executeScript({
      target: { tabId },
      world: 'MAIN',
      func: (leakVar) => !!(window[leakVar] && typeof window[leakVar].pasteSelection === 'function'),
      args: [LEAK_VAR],
    });
    return !!result;
  } catch (e) {
    return false;
  }
}

function captureInstance(tabId) {
  return new Promise(async (resolve, reject) => {
    const target = { tabId };
    let attached = false;
    let breakpointId = null;
    let settled = false;

    const cleanup = async () => {
      chrome.debugger.onEvent.removeListener(onEvent);
      try { if (breakpointId) await sendCmd('Debugger.removeBreakpoint', { breakpointId }); } catch (e) {}
      try { if (attached) await chrome.debugger.detach(target); } catch (e) {}
    };

    const finish = async (err) => {
      if (settled) return;
      settled = true;
      await cleanup();
      if (err) reject(err); else resolve();
    };

    function sendCmd(method, params) {
      return new Promise((res, rej) => {
        chrome.debugger.sendCommand(target, method, params || {}, (result) => {
          if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message));
          else res(result);
        });
      });
    }

    const scripts = [];
    function onEvent(source, method, params) {
      if (!source || source.tabId !== tabId) return;
      if (method === 'Debugger.scriptParsed' && params.url && params.url.includes(SCRIPT_URL_HINT)) {
        scripts.push(params);
      }
    }
    chrome.debugger.onEvent.addListener(onEvent);

    try {
      await new Promise((res, rej) => {
        chrome.debugger.attach(target, '1.3', () => {
          if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message));
          else res();
        });
      });
      attached = true;

      await sendCmd('Debugger.enable');
      // Laisse le temps aux événements scriptParsed (rejoués pour les scripts déjà chargés) d'arriver.
      await wait(400);

      if (scripts.length === 0) {
        throw new Error("Script pixilart_app.js introuvable sur cette page. Êtes-vous bien sur l'éditeur ?");
      }
      const scriptMeta = scripts[scripts.length - 1];

      const src = await sendCmd('Debugger.getScriptSource', { scriptId: scriptMeta.scriptId });
      const text = src.scriptSource || '';
      const anchorOffset = text.indexOf(ANCHOR_TEXT);
      if (anchorOffset === -1) {
        throw new Error("Structure interne de Pixilart non reconnue (le bundle a peut-être changé).");
      }
      // L'ancre se trouve à l'intérieur du test du if() (ex: "46==t.keyCode&&e.deleteSelection()").
      // Poser le point d'arrêt PILE sur cette sous-expression est risqué : CDP peut le faire
      // glisser (snap) en avant jusqu'au prochain point réellement "breakable", qui peut être
      // l'appel e.deleteSelection() lui-même — or cet appel est court-circuité par le "&&" et
      // ne s'exécute donc QUE si le vrai keyCode 46 (Suppr) est pressé. Comme on déclenche un
      // keydown neutre (keyCode 0) pour ne rien supprimer côté utilisateur, ce point ne serait
      // alors jamais atteint. On recule donc jusqu'à l'accolade ouvrante de la fonction pour
      // cibler le tout début de l'instruction if(...), qui s'exécute à CHAQUE frappe.
      const braceIdx = text.lastIndexOf('{', anchorOffset);
      let offset = braceIdx !== -1 ? braceIdx + 1 : anchorOffset;
      while (offset < anchorOffset && /\s/.test(text[offset])) offset++; // tolère un éventuel espace/retour à la ligne
      const { line, column } = offsetToLineColumn(text, offset);

      const bp = await sendCmd('Debugger.setBreakpoint', {
        location: { scriptId: scriptMeta.scriptId, lineNumber: line, columnNumber: column },
        condition: `(window.${LEAK_VAR} = e, false)`,
      });
      breakpointId = bp.breakpointId;

      // Déclenche un keydown neutre (keyCode 0) sur la page pour exécuter le handler.
      await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => {
          document.dispatchEvent(new KeyboardEvent('keydown', { bubbles: true, cancelable: true }));
        },
      });

      // Attend que l'assignation ait eu lieu (poll court).
      let ok = false;
      for (let i = 0; i < 15 && !ok; i++) {
        await wait(80);
        ok = await hasLeak(tabId);
      }
      if (!ok) {
        throw new Error("La capture de l'éditeur Pixilart a échoué (aucune interaction clavier détectée).");
      }

      await finish(null);
    } catch (e) {
      await finish(e);
    }
  });
}

function offsetToLineColumn(text, offset) {
  let line = 0, lastNewline = -1;
  for (let i = 0; i < offset; i++) {
    if (text.charCodeAt(i) === 10) { line++; lastNewline = i; }
  }
  const column = offset - lastNewline - 1;
  return { line, column };
}

function wait(ms) {
  return new Promise((res) => setTimeout(res, ms));
}
